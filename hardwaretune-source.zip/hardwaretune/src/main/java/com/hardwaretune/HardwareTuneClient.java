package com.hardwaretune;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.GameOptions;
import net.minecraft.client.option.GraphicsMode;
import net.minecraft.client.option.ParticlesMode;
import org.lwjgl.opengl.GL11;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.regex.Pattern;

public class HardwareTuneClient implements ClientModInitializer {
    private static final Logger LOG = LoggerFactory.getLogger("HardwareTune");

    // Пресеты по уровню железа: 0 = слабое ... 4 = мощное
    private static final int[] VIEW     = {6, 8, 12, 16, 24};
    private static final int[] SIM      = {5, 6, 8, 10, 12};
    private static final int[] FPS      = {60, 90, 120, 144, 260}; // 260 = без лимита
    private static final double[] ENTITY = {0.5, 0.75, 1.0, 1.25, 1.5};
    private static final int[] BLEND    = {0, 1, 2, 3, 5};
    private static final int[] MIPMAP   = {0, 2, 3, 4, 4};

    @Override
    public void onInitializeClient() {
        ClientLifecycleEvents.CLIENT_STARTED.register(this::tune);
    }

    private void tune(MinecraftClient client) {
        Path marker = FabricLoader.getInstance().getConfigDir().resolve("hardwaretune-applied.txt");
        if (Files.exists(marker)) {
            return; // уже настроено раньше, не трогаем твои ручные изменения
        }
        try {
            int threads = Runtime.getRuntime().availableProcessors();
            long heapMb = Runtime.getRuntime().maxMemory() / (1024 * 1024);
            String gpu = GL11.glGetString(GL11.GL_RENDERER);
            if (gpu == null) gpu = "unknown";

            int gpuTier = gpuTier(gpu);
            int cpuTier = cpuTier(threads);
            int tier = Math.round((gpuTier * 3 + cpuTier * 2) / 5.0f);
            tier = Math.max(0, Math.min(4, tier));

            // Ограничение по выделенной памяти (то, что дал лаунчер)
            int viewCap;
            if (heapMb < 2000) viewCap = 8;
            else if (heapMb < 3000) viewCap = 12;
            else if (heapMb < 4000) viewCap = 16;
            else if (heapMb < 6000) viewCap = 20;
            else viewCap = 32;

            int view = Math.min(VIEW[tier], viewCap);
            int sim = Math.min(SIM[tier], view);

            GameOptions o = client.options;
            o.getViewDistance().setValue(view);
            o.getSimulationDistance().setValue(sim);
            o.getMaxFps().setValue(FPS[tier]);
            o.getEntityDistanceScaling().setValue(ENTITY[tier]);
            o.getBiomeBlendRadius().setValue(BLEND[tier]);
            o.getMipmapLevels().setValue(MIPMAP[tier]);
            o.getGraphicsMode().setValue(tier <= 1 ? GraphicsMode.FAST : GraphicsMode.FANCY);
            o.getParticles().setValue(tier == 0 ? ParticlesMode.MINIMAL
                    : tier == 1 ? ParticlesMode.DECREASED : ParticlesMode.ALL);
            o.write();

            String report = "GPU: " + gpu + " (tier " + gpuTier + ")\n"
                    + "CPU threads: " + threads + " (tier " + cpuTier + ")\n"
                    + "Memory for Minecraft: " + heapMb + " MB\n"
                    + "Final tier: " + tier + "\n"
                    + "Render distance: " + view + ", simulation distance: " + sim + "\n"
                    + "Delete this file to re-apply auto settings on next launch.\n";
            Files.write(marker, List.of(report.split("\n")));
            LOG.info("Applied settings:\n{}", report);
        } catch (Throwable t) {
            LOG.error("HardwareTune failed", t);
        }
    }

    private static int cpuTier(int threads) {
        if (threads <= 2) return 0;
        if (threads < 6) return 1;
        if (threads < 8) return 2;
        if (threads < 12) return 3;
        return 4;
    }

    private static int gpuTier(String name) {
        String s = name.toLowerCase();
        if (s.contains("llvmpipe") || s.contains("software") || s.contains("basic render")) return 0;
        if (s.contains("apple m")) return 3;
        if (Pattern.compile("rtx\\s?(30|40|50)\\d\\d").matcher(s).find()) return 4;
        if (Pattern.compile("rx\\s?(6|7|9)\\d{3}").matcher(s).find()) return 4;
        if (Pattern.compile("rtx\\s?20\\d\\d").matcher(s).find()) return 3;
        if (Pattern.compile("gtx\\s?10(70|80)").matcher(s).find()) return 3;
        if (s.contains("gtx") || Pattern.compile("rx\\s?5\\d{2,3}").matcher(s).find()) return 2;
        if (Pattern.compile("rx\\s?[34]\\d\\d").matcher(s).find()) return 1;
        if (s.contains("intel") || s.contains("uhd") || s.contains("iris")
                || s.contains("vega") || s.contains("radeon(tm) graphics")
                || s.contains("radeon graphics")) return 0;
        return 2; // неизвестная видеокарта — берём середину
    }
}
